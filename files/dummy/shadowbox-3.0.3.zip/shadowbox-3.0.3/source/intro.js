/*!
 * Shadowbox.js, version @VERSION
 * http://shadowbox-js.com/
 *
 * Copyright 2007-2010, Michael J. I. Jackson
 * @DATE
 */
(function(window, undefined) {
